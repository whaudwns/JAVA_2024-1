/*
 * 작성일
 * 작성자
 * 설명 : 조건식 연습
 * 		숫자와 연산자를 입력 받아
 * 		사칙연산 프로그램을 작성하시오.
 * 		입력 방식 : 3 + 4 (띄어쓰기로 구분)
 * 
 * [문제 분석 및 알고리즘]
 * 		숫자 연산자 숫자를 입력 받아
 * 		해당 연산자에 따른 결과를 출력한다.
 * 
 * 		나눗셈의 결과는 소수자리가 나온다.
 * 		소수 2자리까지 출력한다.
 * 		
 * 		나누기 할 때는 0으로 나눌 수 없습니다.
 * 		두번째 수가 0이면
 * 		"나눌 수 없습니다." 출력하기
 */

import java.util.Scanner;

public class SwitchTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Scanner 개체 생성
		Scanner stdIn = new Scanner(System.in);
		
		System.out.print("계산식을 입력하시오(3 + 4) : ");
		int num1 = stdIn.nextInt();
		/* 
		 * 사용자로부터 입력된 문자열에서 첫 번째 문자, 즉 연산자를 추출한다.
		 * 
		 * 
		 */
		char op = stdIn.next().charAt(0);
		int num2 = stdIn.nextInt();
		
		
	}

}
