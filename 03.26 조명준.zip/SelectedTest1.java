/*
 * 작성일
 * 작성자
 * 설명 : 세자리의 십진수를 입력받아 각자리의 숫자들이 짝수인지 홀수인지 판단
 * 
 * [문제 해석]
 * 		짝수는 2로 나눈 나머지가 0이다.
 * 		홀수는 2로 나눈 나머지가 1이다.(0이 아니다.)
 * 		세자리 수 : 100~999
 * 		123을 입력했을때 
 * 		100의 자리는 1 홀수입니다.
 * 		10의 자리는 2 짝수입니다.
 * 		1의 자리는 3 홀수입니다.
 * 		
 * 		100의 자리, 10의 자리, 1의 자리를 구분한다.
 * 		나누기 연산자를 활용한다.
 * 
 * [알고리즘]
 * 		1. 세 자리 정수를 입력한다.
 * 		2. 입력한 정수가 세자리 정수가 맞나요?
 * 		
 * 		3.
 * 
 */

import java.util.Scanner;

public class SelectedTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Scanner 개체 생성
				Scanner stdIn = new Scanner(System.in);
				
				//1. 세자리 정수를 입력한다.
				System.out.print("세 자리수를 입력하시오 : ");
				int num = stdIn.nextInt();
				// 2. 세자리 정수가 맞나
				if(num >= 100 && num < 1000) // 100~999
				{
					int num_100 = num / 100; // 100의 자리 몫 찾기
					int num_10 = (num % 100) / 10; //10의 자리 몫 찾기
					int num_1 = (num % 100) % 10; // 1의 자리 몫 찾기
				} else { // 3. 세자리가 아니면
					System.out.println("잘못 입력하였습니다.");
				}
				
				
				
	}

}
