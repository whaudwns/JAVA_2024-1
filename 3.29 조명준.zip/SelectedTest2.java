/*
 * 작성자
 * 작성일
 * 설명
 * 두 정수를 입력받아 두 수가 모두 짝수이면 더한 결과를 출력하고,
 * 그렇지 않으면 두 수중 하나라도 홀수이면 몇 번째 입력한 수를 짝수로
 * 입력해야 하는지 출력하시오.
 * (첫 번째 정수가 홀수이면 "첫 번째 수를 짝수로 입력하세요"라고 출력
 * [문제 분석]
 * 		짝수는 2로 나눈 나머지가 0이다.
 * 		홀수는 2로 나눈 나머지가 1이다.(0이 아니다.)
 * 
 * [알고리즘]
 * 		1. 정수 2개를 입력받는다.
 * 		2. 두 정수가 짝수인지 홀수인지 판단한다.
 * 		2-1. 두 정수 중에 하나라도 홀수이면...
 * 		2.2. 두 정수 중에 하나가 0이라면...
 * 		3. 두 수를 더한 값을 출력한다.
 * 
 * 
 */

import java.util.Scanner;

public class SelectedTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Scanner 개체 생성
		Scanner stdIn = new Scanner(System.in);
		//1. 정수 입력 받기
		System.out.println("첫 번째 정수를 입력 : ");
		int num1 = stdIn.nextInt();
		System.out.println("두 번째 정수를 입력 : ");
		int num2 = stdIn.nextInt();
		
		if(num1 % 2 == 0 && num2 % 2 == 0) {
			System.out.println(num1 + "+" + num2 + "=" + (num1+num2));
		} else if(num1 % 2 == 1 && num2 % 2 == 0){
			System.out.println("첫 번째 정수를 짝수로 입력하세요.");
		} else if(num1 % 2 == 0 && num2 % 2 == 1){
			System.out.println("두 번째 정수를 짝수로 입력하세요.");
		} else{
			System.out.println("두 정수 모두 짝수로 입력하세요.");
		}
		

	}

}
