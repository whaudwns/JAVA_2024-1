/*
 * 작성일 : 2024년 3월 19일
 * 작성자 :
 * 설명 : 단순 If문 실습
 * 		하나의 정수를 입력받아 0보다 작은지 판단.
 * 		
 * 문제분석 : 음수는 0보다 작은 수이다.
 * 			정수를 입력받아 0보다 작은지 비교,판단
 * 
 * 알고리즘 : 1. 정수를 입력받는다.
 * 			2. 입력받은 정수가 0보다 작은지 판단한다.
 * 			2-1. -()는 음수입니다.  출력한다.
 */

import java.util.Scanner;

public class SimpleIfTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			// Scanner 개체 생성
			Scanner stdIn = new Scanner(System.in);
			
			//1. 정수를 입력한다.
			System.out.print("정수 입력 : ");
			int num = stdIn.nextInt();
			
			// 2. 음수인지 판단
			//만약에 변수에 저장된 값
			If(num < 0) {
				System.out.printIn(num + "은 음수입니다.");
			
			} //If 종료 지점
			
			//조건과 상관없이 무조건 출력되는 문장.
			System.out.printIn("프로그램 종료");
			
			
	}

}
