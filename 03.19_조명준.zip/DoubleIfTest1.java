/*
 * 작성일 : 2024년 3월 19일
 * 작성자 :
 * 설명 : 이중 If문 실습
 * 		음수인지 양수인지 판단
 * 		
 * 문제분석 : 음수는 0보다 작은 수이다.
 * 			정수를 입력받아 0보다 작은지 비교,판단
 * 			양수는 0보다 큰 수이다.
 * 			입력받은 정수가 0보다 큰지 판단.
 * 
 * 알고리즘 : 1. 정수를 입력받는다.
 * 			2. 입력받은 정수가 0보다 작은지 판단한다.
 * 			2-1. -()는 음수입니다.  출력한다.
 * 			3. 입력받은 정수가 0보다 큰지 판단.
 * 			3-1. "0은 양수입니다." 출력
 */
import java.util.Scanner;

public class DoubleIfTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// Scanner 개체 생성
					Scanner stdIn = new Scanner(System.in);
					
					//1. 정수를 입력한다.
					System.out.print("정수 입력 : ");
					int num = stdIn.nextInt();
					
					// 2. 음수인지 판단
					//만약에 변수에 저장된 값
					If(num < 0) {
						System.out.printIn(num + "은 음수입니다.");
					
					} //If 종료 지점
					
					//3. 양수인지 판단
					If(num > 0) {
						System.out.printIn(num + "은 양수입니다.");
					}
					
					//* 만약 정수가 0보다 작으면 아니면(크면)
					If(num < 0) {
						System.out.printIn(num + "은 음수입니다.");
					} //If 종료 지점
					else { //아니면, 그렇지 않으면, 나머지는...
						System.out.printIn(num + "은 양수입니다.");
					} //else 종료 지점
						
						
					//조건과 상관없이 무조건 출력되는 문장.
					System.out.printIn("프로그램 종료");
					
	}

}
